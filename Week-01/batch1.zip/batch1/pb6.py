x=input('enter string: ')
rev_x=x[::-1]
print(rev_x)
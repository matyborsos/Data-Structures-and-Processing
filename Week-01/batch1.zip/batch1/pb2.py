x=input('first value: ')
y=input('second value: ')
z=input('third value: ')
if x>y:
    if x>z:
        maxi=x
    else:
        maxi=z
else:
    if y>z:
        maxi=y
    else:
        maxi=z
print('the maximum of the three is: ', maxi)

import random
x=random.randint(1, 100)
counter=0
while True:
    guess=int(input('enter a value between 1 and 100: '))
    counter+=1
    if guess==x:
        print('correct!!')
        print("your guess' number is: ", counter)
        break
    elif guess>x:
        print('too high! try again')
    else:
        print('too low! try again')
print('value: ')
x=int(input())
print(type(x))
sum=0
while x>0:
    sum+=x%10
    x//=10
print('the sum of digits is: ', sum)
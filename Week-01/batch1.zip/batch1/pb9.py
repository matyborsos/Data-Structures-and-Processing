n=int(input('enter number of elements: '))
lst=[]
for i in range(n):
    elem=int(input())
    lst.append(elem)
print('the average of the list is: ', sum(lst)/len(lst))
import statistics as st

lst=[]
n=int(input('enter number of elements: '))
for i in range(n):
    elem=int(input())
    lst.append(elem)
print('the median is: ', st.median(lst))

x=int(input('value: '))
for i in range(x):
    print('*', end=" ")


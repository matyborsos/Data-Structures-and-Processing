lst=[]
n=int(input('number of elements: '))
print('enter elements')
for i in range(n):
    x=int(input())
    lst.append(x)

mini=lst[0]
maxi=lst[0]

for i in range(n):
    if lst[i]<mini:
        mini=lst[i]
    if lst[i]>maxi:
        maxi=lst[i]

print('the maximum of the list is: ', maxi)
print('the minimum of the list is: ', mini)


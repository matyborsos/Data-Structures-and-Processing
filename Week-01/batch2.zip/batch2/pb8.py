def reverse_string(str):
    return str[::-1]

str=input('enter string:')
rev_str=reverse_string(str)
print('the reversed string is:', rev_str)

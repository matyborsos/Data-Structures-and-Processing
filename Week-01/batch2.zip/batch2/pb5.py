import math
def power(n, m):
    return math.pow(n, m)

a=int(input('enter base: '))
b=int(input('enter exponent: '))
result=power(a, b)
print('the result is:', result)
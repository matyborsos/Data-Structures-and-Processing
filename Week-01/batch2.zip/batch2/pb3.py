def palindrome(s):
    return s==s[::-1]

str=input('enter string: ')
result=palindrome(str)
if result==True:
    print('the string is a palindrome')
else:
    print('the string is not a palindrome')
def largest_string(list):
    maxi=-1
    for i in range(len(list)):
        if len(list[i])>maxi:
            maxi=len(list[i])
            str=list[i]
        elif len(list[i])==maxi:
            if str<list[i]:
                str=list[i]
    return str

lst=[]
n=int(input('enter number of elements: '))
for i in range(n):
    elem=input('enter string: ')
    lst.append(elem)
stri=largest_string(lst)
print('the largest string is', stri)
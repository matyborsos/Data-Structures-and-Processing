def gcd(n, m):
    while m!=0:
        r=n%m
        n=m
        m=r
    return n

elem1=int(input('enter first value: '))
elem2=int(input('enter second value: '))
divisor=gcd(elem1, elem2)
print('the greatest common divisor is: ', divisor)

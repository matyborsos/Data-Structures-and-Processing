def lower_str(str):
    return str.lower()

str=input('enter string: ')
lowstr=lower_str(str)
print('the string in all lowercase is:', lowstr)

def factorial(n):
    if n==1 or n==0:
        return 1
    else:
        fact=1
        while n>=1:
            fact*=n
            n-=1
        return fact

n=int(input('enter value: '))
fact=factorial(n)
print('the factorial is:', fact)

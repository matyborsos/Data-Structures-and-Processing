def upper_string(str):
    return str.upper()

str=input('enter string:')
upstr=upper_string(str)
print('the string in all uppercase is:', upstr)


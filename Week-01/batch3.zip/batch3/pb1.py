def c_to_f(temp):
    newtemp=temp*(9/5)+32
    return newtemp

def f_to_c(temp):
    newtemp=(temp-32)*(5/9)
    return newtemp

temptype=input("enter the temperature type (celsius/farenheit)") 
temp=int(input('enter temperature:'))
temptype=temptype.lower()
if temptype=="celsius":
    convtemp=c_to_f(temp)
else:
    convtemp=f_to_c(temp)
print('the converted temperature is:', convtemp)
string=input("enter a sentence: ")
string=string.split()
newstring=[]
for i in string:
    newstring.append(i.capitalize())
print("modified string:", " ".join(newstring))
string=input("enter a string: ")
counter=0
string=string.split()
for i in string:
    counter+=1
print("number of words:", counter)

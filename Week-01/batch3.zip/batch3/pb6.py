string=input("enter a sentence: ")
string=string.split()[::-1]
newstring=[]
for i in string:
    newstring.append(i)
print(" ".join(newstring))
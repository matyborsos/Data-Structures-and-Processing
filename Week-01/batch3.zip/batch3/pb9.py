string=input("enter a string: ")
counter=0
string=string.lower()
for i in string:
    if i in ('a', 'e', 'i', 'o', 'u'):
        counter+=1
print("number of vowels:", counter)
n=int(input('number of assignments: '))
assignment=[]
weight=0
sum=0
for i in range(n):
    a=int(input('enter assignment grade: '))
    w=int(input('enter weight: '))
    sum+=a*w
    weight+=w
exam=int(input('exam grade: '))
w=int(input('enter weight: '))
sum+=exam*w
weight+=w
print('the final grade is:', sum/weight)

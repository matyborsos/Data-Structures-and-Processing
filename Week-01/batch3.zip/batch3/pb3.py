n=int(input('enter number: '))
if n%2==1:
    print('the number is odd')
else:
    print('the number is even')
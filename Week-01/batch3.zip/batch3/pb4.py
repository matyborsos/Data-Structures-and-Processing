def isprime(n):
    if n==1 or n==0:
        return 0
    if n==2:
        return 1
    if n%2==0:
        return 0
    for d in range(3, n//2, 3):
        if n%d==0:
            return 0
    return 1

n=int(input('enter number '))
prime=isprime(n)
if prime==1:
    print('the number is prime!')
else:
    print('the number is not prime!')
lst=[]
n=int(input("enter the number of elements: "))
for i in range(n):
    elem=int(input("enter elements: "))
    lst.append(elem)

print("the reversed list is:", lst[::-1])

import numpy as np
arr=np.random.random(size=50)
print(arr.max())

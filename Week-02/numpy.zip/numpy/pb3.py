import numpy as np
arr=np.identity(3)
print(arr)
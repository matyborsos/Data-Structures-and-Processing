import numpy as np
arr=np.random.randint(0, 1000, size=(5,5))
print(arr[2,:])
print(arr[:,3])
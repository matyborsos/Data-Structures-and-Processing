import numpy as np
arr=np.random.randint(0, 1000, size=100)
print("mean:", np.mean(arr))
print("standard deviation:", np.std(arr))
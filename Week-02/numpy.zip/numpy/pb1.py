import numpy as np
arr=np.random.randint(0, 1000, size=10)
print(arr)
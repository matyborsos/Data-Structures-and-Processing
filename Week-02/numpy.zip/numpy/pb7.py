import numpy as np
arr1=np.random.randint(1, 100, size=5)
arr2=np.random.randint(1, 100, size=5)
print("dot product:", np.dot(arr1, arr2))
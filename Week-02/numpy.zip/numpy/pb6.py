import numpy as np
arr=np.random.randint(1, 10, size=(3,3))
print(arr)
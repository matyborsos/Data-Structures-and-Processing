import numpy as np
arr=np.random.randint(1, 100, size=(3, 3))
print(arr)
print("eigenvalues:",np.linalg.eigvals(arr))
print("eigenvectors:",np.linalg.eig(arr))
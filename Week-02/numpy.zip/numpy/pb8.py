import numpy as np
arr=np.random.randint(1, 100, size=10)
arr=arr.reshape(2, 5)
print(arr)
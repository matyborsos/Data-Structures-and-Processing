import numpy as np
arr1=np.random.randint(0, 100, size=10)
arr2=np.random.randint(0, 100, size=(3,3))
arr3=np.concatenate((arr1, arr2), axis=None)
print(arr3)